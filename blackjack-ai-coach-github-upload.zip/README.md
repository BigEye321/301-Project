﻿# Blackjack AI Coach

Table Sense, Not Just Table Math.

This repository contains the completed Project 301 MVP in the `mvp/` directory.

## Streamlit Community Cloud

Use this main file path:

```text
mvp/app.py
```

Install from:

```text
mvp/requirements.txt
```

## Run Locally

```powershell
cd mvp
pip install -r requirements.txt
python -m streamlit run app.py
```
